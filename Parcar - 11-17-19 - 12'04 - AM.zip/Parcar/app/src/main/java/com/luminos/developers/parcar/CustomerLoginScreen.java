package com.luminos.developers.parcar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CustomerLoginScreen extends AppCompatActivity {
    //Global Strings
    public static String username;
    public static String password;

    public void saveLocallyCredentials(){
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username", username);
        editor.apply();

    }
    //Login Button Clicked Event handler
    public void LoginButtonIsPressed (View loginButton) {
        EditText usrEntry = findViewById(R.id.username_entry);
        EditText passEntry = findViewById(R.id.password_entry);

        //Values of user input
        String usernameByUser = usrEntry.getText().toString();
        String passwordByUser = passEntry.getText().toString();


        //Firebase Initilize
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Customer Accounts").child(usernameByUser);

        //gets values from database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                username = dataSnapshot.child("Information").child("Username").getValue().toString();
                password = dataSnapshot.child("Information").child("Password").getValue().toString();
                Log.i("MyTag","Value is: " + username + " :" + password);
                ValidateLogin();

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(CustomerLoginScreen.this, "Username Not Found", Toast.LENGTH_SHORT).show();
            }
        });
    }

    //Function that opens up the signup screen
    public void openAfterLoginScreen () {
        Intent intent = new Intent(this, CustomerDashboard.class);
        startActivity(intent);
    }
    public void openSignUpScreen () {
        Intent intent = new Intent(this, CustomerSignUpScreen.class);
        startActivity(intent);
    }

    //Validates the login
    public void ValidateLogin() {
        EditText usrEntry = findViewById(R.id.username_entry);
        EditText passEntry = findViewById(R.id.password_entry);

        //Values of user input
        String usernameByUser = usrEntry.getText().toString();
        String passwordByUser = passEntry.getText().toString();


        Log.i("MyTag","Value is: " + username + " :" + password);
        if (usernameByUser.equals(username) && passwordByUser.equals(password)) {
            Toast.makeText(this, "Login Success", Toast.LENGTH_SHORT).show();
            saveLocallyCredentials();
            openAfterLoginScreen();

        }
        else {
            Log.i("MyTag", "Unsuccessful");
            Toast.makeText(this, "Login Failure", Toast.LENGTH_SHORT).show();
        }
    }

    public void signUpButtonIsPressed(View signUpButton) {

        openSignUpScreen();
    }

    public void hideNavigation(){
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_login_screen);

        hideNavigation();

    }
}
