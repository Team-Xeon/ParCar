package com.luminos.developers.parcar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DriverDashboard extends FragmentActivity implements OnMapReadyCallback {
    GoogleMap map;
    public static String usernameOfLocalUser;
    public static String selected;

    public void getLocalUser(){
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_WORLD_READABLE);
        usernameOfLocalUser = sharedPreferences.getString("username","error");

    }

    public void hideNavigation(){
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    public void getCustomerList(){
        //Firebase Initilize
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Customer Events");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String username = snapshot.getKey();
                    String location = snapshot.child("address").getValue().toString();
                    String type = snapshot.child("order type").getValue().toString();
                    displayCustomerEvent(username,location,type);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void displayCustomerEvent(final String username, String Location, String type){

        LinearLayout linearLayout = findViewById(R.id.EventLog);
        LinearLayout linearLayout1 = new LinearLayout(this);
        linearLayout1.setOrientation(LinearLayout.HORIZONTAL);


        ImageView img = new ImageView(this);
        if (type.equals("premium")) {
            img.setImageResource(R.drawable.ic_directions_car2_black_24dp);

        } else{
            img.setImageResource(R.drawable.ic_directions_car_black_24dp);

        }
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(DriverDashboard.this, "Selected", Toast.LENGTH_SHORT).show();
                selected = username;
            }
        });


        TextView title = new TextView(this);
        title.setText("Username: \n" + username);
        title.setTextSize(15);
        title.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(DriverDashboard.this, "Selected", Toast.LENGTH_SHORT).show();
                selected = username;
            }
        });

        TextView Location1 = new TextView(this);
        Location1.setText("Location: \n" + Location);
        Location1.setTextSize(15);
        Location1.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        Location1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(DriverDashboard.this, "Selected", Toast.LENGTH_SHORT).show();
                selected = username;
            }
        });
        linearLayout1.addView(img);
        linearLayout1.addView(title);
        linearLayout1.addView(Location1);
        linearLayout.addView(linearLayout1);
    }

    public void AcceptButtonIsClicked(View acceptButton){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Customer Events").child(selected);

        myRef.child("status").setValue("booked");
        myRef.child("driver").setValue(usernameOfLocalUser);
        Toast.makeText(this, "Customer Booked", Toast.LENGTH_SHORT).show();
    }

    public void DeclineButtonIsClicked(View declineButton){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Customer Events").child(selected);

        myRef.child("status").setValue("looking");
        myRef.child("driver").setValue(usernameOfLocalUser);
        Toast.makeText(this, "Customer Canceled", Toast.LENGTH_SHORT).show();

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_dashboard);

        getLocalUser();
        hideNavigation();

        getCustomerList();

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);


    }

    @Override
    public void onMapReady(GoogleMap googlemap) {

        map = googlemap;
        LatLng SFO = new LatLng(37.783675599999995, -122.41273609999999);
        map.addMarker(new MarkerOptions().position(SFO).title("Make School"));
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(SFO, 14));
    }
}
