package com.luminos.developers.parcar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

import static android.view.View.GONE;

public class CustomerDashboard extends AppCompatActivity implements OnMapReadyCallback {
    // Global Strings
    GoogleMap map;
    public String strAddress = "ERROR";
    public String orderType = "regular";
    public String premium_instructions = "ERR";
    public String usernameOfLocalUser;
    public String driver = "Loading...";


    public void getLocalUser(){
        SharedPreferences sharedPreferences = getSharedPreferences("LocalUsers", MODE_WORLD_READABLE);
        usernameOfLocalUser = sharedPreferences.getString("username","error");

    }

    public void hideNavigation(){
        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    public void MapCheckButtonIsClicked(View mapCheckButton){

        EditText locationAddress = findViewById(R.id.addressInput);
        strAddress = locationAddress.getText().toString();

        Geocoder coder= new Geocoder(this);
        List<Address> address;
        LatLng p1;

        try
        {
            address = coder.getFromLocationName(strAddress, 5);
            if(address == null)
            {
                Toast.makeText(this, "Error finding address", Toast.LENGTH_SHORT).show();;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            p1 = new LatLng(location.getLatitude(), location.getLongitude());
            map.addMarker(new MarkerOptions().position(p1).title("Selected Location"));
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(p1, 14));
            AddAddressToList();
        }
        catch (Exception e)
        {
            Toast.makeText(this, "Error finding Address", Toast.LENGTH_SHORT).show();
        }


    }

    public void AddAddressToList(){
        TextView address = findViewById(R.id.addressOutput);
        address.setText(strAddress);
    }

    public void popupdialog(){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(CustomerDashboard.this);
        alertDialog.setTitle("Premium");
        alertDialog.setMessage("Extra Instructions");

        final EditText input = new EditText(CustomerDashboard.this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        input.setLayoutParams(lp);
        alertDialog.setView(input);

        alertDialog.setPositiveButton("Submit",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        premium_instructions = input.getText().toString();
                        Toast.makeText(getApplicationContext(),
                                        "Accepted", Toast.LENGTH_SHORT).show();
                    }
                });

        alertDialog.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        alertDialog.show();
    }


    public void PremiumButtonIsClicked(View premium_button){
        orderType = "regular";

        ImageView premiumHighlight = findViewById(R.id.regular_highlighted);
        premiumHighlight.setVisibility(View.GONE);

        ImageView regularHighlight = findViewById(R.id.premium_highlighted);
        regularHighlight.setVisibility(View.VISIBLE);

        popupdialog();

    }

    public void RegularButtonIsClicked(View imageView17){
        orderType = "premium";

        ImageView premiumHighlight = findViewById(R.id.premium_highlighted);
        premiumHighlight.setVisibility(View.GONE);

        ImageView regularHighlight = findViewById(R.id.regular_highlighted);
        regularHighlight.setVisibility(View.VISIBLE);
    }

    public void ReserveButtonIsClicked(View reserveButton) {
        if (strAddress.equals("ERROR")){
            Toast.makeText(this, "You did not choose a location!", Toast.LENGTH_SHORT).show();
        } else {

            FirebaseDatabase database = FirebaseDatabase.getInstance();
            Log.i("MyTag", usernameOfLocalUser);
            DatabaseReference myRef = database.getReference("Customer Events").child(usernameOfLocalUser);

            myRef.child("Status").setValue("Looking");
            myRef.child("address").setValue(strAddress);
            myRef.child("instructions").setValue(premium_instructions);
            myRef.child("order type").setValue(orderType);


            // Destroy all elements
            TextView one = findViewById(R.id.addressOutput);
            one.setVisibility(GONE);

            TextView two = findViewById(R.id.textView6);
            two.setVisibility(GONE);

            TextView three = findViewById(R.id.textView4);
            three.setVisibility(GONE);

            TextView four = findViewById(R.id.textView5);
            four.setVisibility(GONE);

            TextView five = findViewById(R.id.textView7);
            five.setVisibility(GONE);

            TextView six = findViewById(R.id.textView10);
            six.setVisibility(GONE);

            TextView seven = findViewById(R.id.textView8);
            seven.setVisibility(GONE);

            TextView eight = findViewById(R.id.textView9);
            eight.setVisibility(GONE);

            ImageView nine = findViewById(R.id.regular_button);
            nine.setVisibility(GONE);

            ImageView ten = findViewById(R.id.premium_button);
            ten.setVisibility(GONE);

            ImageView eleven = findViewById(R.id.regular_highlighted);
            eleven.setVisibility(GONE);

            ImageView twelve = findViewById(R.id.premium_highlighted);
            twelve.setVisibility(GONE);

            ImageView thirteen = findViewById(R.id.reserveButton);
            thirteen.setVisibility(GONE);

            ImageView cancel = findViewById(R.id.cancelButton);
            cancel.setVisibility(View.VISIBLE);

            ProgressBar progressBar = findViewById(R.id.progressBar1);
            progressBar.setVisibility(View.VISIBLE);

        }

    }

    public void cancelButtonIsPressed(View cancelButton){

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Customer Events").child(usernameOfLocalUser);

        myRef.child("Status").removeValue();
        myRef.child("address").removeValue();
        myRef.child("instructions").removeValue();
        myRef.child("order type").removeValue();

        // Gets back all elements
        TextView one = findViewById(R.id.addressOutput);
        one.setVisibility(View.VISIBLE);

        TextView two = findViewById(R.id.textView6);
        two.setVisibility(View.VISIBLE);

        TextView three = findViewById(R.id.textView4);
        three.setVisibility(View.VISIBLE);

        TextView four = findViewById(R.id.textView5);
        four.setVisibility(View.VISIBLE);

        TextView five = findViewById(R.id.textView7);
        five.setVisibility(View.VISIBLE);

        TextView six = findViewById(R.id.textView10);
        six.setVisibility(View.VISIBLE);

        TextView seven = findViewById(R.id.textView8);
        seven.setVisibility(View.VISIBLE);

        TextView eight = findViewById(R.id.textView9);
        eight.setVisibility(View.VISIBLE);

        ImageView nine = findViewById(R.id.regular_button);
        nine.setVisibility(View.VISIBLE);

        ImageView ten = findViewById(R.id.premium_button);
        ten.setVisibility(View.VISIBLE);

        ImageView eleven = findViewById(R.id.regular_highlighted);
        eleven.setVisibility(View.VISIBLE);

        ImageView twelve = findViewById(R.id.premium_highlighted);
        twelve.setVisibility(GONE);

        ImageView thirteen = findViewById(R.id.reserveButton);
        thirteen.setVisibility(View.VISIBLE);

        ImageView cancel = findViewById(R.id.cancelButton);
        cancel.setVisibility(GONE);

        ProgressBar progressBar = findViewById(R.id.progressBar1);
        progressBar.setVisibility(GONE);
    }

    public void DriverFound(){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Customer Events").child(usernameOfLocalUser);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                driver = dataSnapshot.child("driver").getValue().toString();
                Toast.makeText(CustomerDashboard.this, driver, Toast.LENGTH_SHORT).show();

                }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        ProgressBar progressBar = findViewById(R.id.progressBar1);
        progressBar.setVisibility(GONE);

        ImageView imageView = findViewById(R.id.cancelButton);
        imageView.setVisibility(GONE);

        TextView textView = findViewById(R.id.addressOutput);
        textView.setVisibility(View.VISIBLE);
        textView.setText("Your Driver is: \n" + driver);
        textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_dashboard);

        TextView textView = findViewById(R.id.addressOutput);
        textView.setText("Add an address above");

        ProgressBar progressBar = findViewById(R.id.progressBar1);
        progressBar.setVisibility(GONE);

        getLocalUser();

        ImageView cancel = findViewById(R.id.cancelButton);
        cancel.setVisibility(GONE);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Customer Events").child(usernameOfLocalUser);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String status = dataSnapshot.child("status").getValue().toString();
                Toast.makeText(CustomerDashboard.this, status, Toast.LENGTH_SHORT).show();

                if (status.equals("booked")){
                    Toast.makeText(CustomerDashboard.this, "Driver Found", Toast.LENGTH_SHORT).show();
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = database.getReference("Customer Events").child(usernameOfLocalUser);
                    myRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            driver = dataSnapshot.child("driver").getValue().toString();
                            Toast.makeText(CustomerDashboard.this, driver, Toast.LENGTH_SHORT).show();
                            DriverFound();

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });


                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        hideNavigation();
        ImageView highlight = findViewById(R.id.premium_highlighted);
        highlight.setVisibility(GONE);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googlemap) {

        map = googlemap;
        LatLng SFO = new LatLng(37.783675599999995, -122.41273609999999);
        map.addMarker(new MarkerOptions().position(SFO).title("Make School"));
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(SFO, 14));
    }
}
